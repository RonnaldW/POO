/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.banco;

/**
 *
 * @author Ronnald
 */
public class Pessoa {
    String nome ;
    int idade ;
    char sexo ;
    String cpf ;
    
    void aniversario(){
        this.idade = this.idade + 1;
    }
    
    void atribuiCPF(String c){
        this.cpf = c;
    }
    
    int getIdade(){
        return this.idade ;
    }
}