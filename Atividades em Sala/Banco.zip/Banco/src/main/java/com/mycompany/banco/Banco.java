/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.banco;

/**
 *
 * @author Ronnald
 */


import java.util.Scanner;

public class Banco {
    public static void main(String[] args) {

        // Criando 4 objetos da classe Pessoa

        // Criando 2 objetos da classe Gerente

        // Criando 2 objetos da classe ContaCorrente


        // Criando 2 objetos da classe Poupanca


        // Exibindo informações das contas criadas



    }
}
